let spaceMaterialCounter = document.querySelector('#space-material');
let spaceMaterial = 0;
if(localStorage.spaceMaterial) {
    spaceMaterial = localStorage.spaceMaterial;
}
spaceMaterialCounter.innerText = "Space material: " + spaceMaterial;

function addSpaceMaterial() {
    spaceMaterial++;
    localStorage.spaceMaterial = spaceMaterial;
    spaceMaterialCounter.innerText = "Space material: " + spaceMaterial;
    let plusPoint = document.createElement("div");
    plusPoint.innerText = "+1";
    plusPoint.classList.add('plus-point');
    document.querySelector('#center').append(plusPoint);
    setTimeout(function() {
        plusPoint.classList.add('plus-point-hide');
     }, 100);
     setTimeout(function() {
        plusPoint.remove()
     }, 2000);
}

document.querySelector('#planet').addEventListener('click', addSpaceMaterial);
