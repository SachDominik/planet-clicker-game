function incomingMeteorite() {
    let meteorite = document.createElement("div");
    meteorite.classList.add('meteorite');
    let randomCoordinateX = Math.round(Math.random()*1000 + 1000)*(Math.random() < 0.5 ? -1 : 1);
    let randomCoordinateY = Math.round(Math.random()*1000 + 1000)*(Math.random() < 0.5 ? -1 : 1);
    let randomTransform = "translate(" + randomCoordinateX + "px," + randomCoordinateY + "px)";
    meteorite.style.transform = randomTransform;
    document.querySelector('#center').append(meteorite);

    setTimeout(function() {
       meteorite.style.transform = "translate(0,150px)"
    }, 500);
    setTimeout(function() {
        addSpaceMaterial();
    }, 5300);
    setTimeout(function() {
        meteorite.remove();
    }, 6000);
}

let meteoriteSpeed = 1000;

setInterval(function() {
    incomingMeteorite()
}, meteoriteSpeed);

